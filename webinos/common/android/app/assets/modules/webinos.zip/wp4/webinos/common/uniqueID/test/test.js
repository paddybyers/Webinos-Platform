var uniqueID = require('../lib/uniqueID.js');

console.log("UUID 40 bit: " + uniqueID.getUUID_40);
console.log("UUID 64 bit: " + uniqueID.getUUID_64);
console.log("UUID 128 bit: " + uniqueID.getUUID_128);