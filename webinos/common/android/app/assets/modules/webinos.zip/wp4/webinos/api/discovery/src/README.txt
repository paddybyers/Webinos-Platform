For Descriptions on the demo, see link -

http://dev.webinos.org/redmine/projects/t61/wiki/Service_and_Device_Discovery_using_Bluetooth


TODO:
[1] Clean up bluetooth.cc code 
[2] Investigate interfacing with RPC
[3] Current remote discovery relys on IP address, this should be repalced by username -> further investigation required
[4] Remote discovery -> NAT traversal needs to be investigated



For more details or any issue, please contact ziran.sun@samsung.com


