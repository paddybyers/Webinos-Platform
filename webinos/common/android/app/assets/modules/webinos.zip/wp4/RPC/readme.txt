Start: node websocketserver.js
(on linux use sudo)

and:
Client @ localhost/client/client.html
